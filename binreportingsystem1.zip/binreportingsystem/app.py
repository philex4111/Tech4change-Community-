from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

# --- User Accounts ---
users = {
    "resident1": {"password": "res123", "role": "resident"},
    "resident2": {"password": "res234", "role": "resident"},
    "resident3": {"password": "res345", "role": "resident"},
    "resident4": {"password": "res456", "role": "resident"},
    "manager": {"password": "admin123", "role": "manager"},
    "admin": {"password": "admin001", "role": "admin"}  # ✅ Added Admin
}

# --- In-memory data structures ---
reports = []        # Stores waste reports
messages = []       # Stores messages from manager/admin to residents
assignments = []    # Stores assigned collection dates


# --- Home Page ---
@app.route('/')
def home():
    return render_template('index.html')


# --- Login Page ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and users[username]['password'] == password:
            role = users[username]['role']
            if role == "resident":
                return redirect(url_for('report', user=username))
            elif role == "manager":
                return redirect(url_for('dashboard'))
            elif role == "admin":
                return redirect(url_for('admin_dashboard'))
        else:
            return render_template('login.html', error="Invalid username or password!")

    return render_template('login.html')


# --- Logout Route ---
@app.route('/logout')
def logout():
    return redirect(url_for('home'))


# --- Resident Report Page ---
@app.route('/report/<user>', methods=['GET', 'POST'])
def report(user):
    if user not in users or users[user]['role'] != "resident":
        return redirect(url_for('login'))

    if request.method == 'POST':
        full_bin = 'Yes' if 'full_bin' in request.form else 'No'
        concerns = request.form.get('concerns', '')
        date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        report_entry = {
            "resident": user,
            "status": "Full" if full_bin == "Yes" else "Empty",
            "concerns": concerns,
            "date": date
        }
        reports.append(report_entry)

    user_reports = [r for r in reports if r['resident'] == user]
    user_messages = [m for m in messages if m['receiver'] == user]
    user_assignments = [a for a in assignments if a['resident'] == user]
    last_collection = user_assignments[-1]['collection_date'] if user_assignments else None

    return render_template(
        'resident_report.html',
        user=user,
        reports=user_reports,
        messages=user_messages,
        assignments=user_assignments,
        last_collection=last_collection
    )


# --- Manager Dashboard ---
@app.route('/dashboard')
def dashboard():
    resident_status = []

    for r in [u for u in users if users[u]['role'] == "resident"]:
        last_report = next((rep for rep in reversed(reports) if rep['resident'] == r), None)
        last_status = last_report['status'] if last_report else "Empty"
        color = "red" if last_status == "Full" else "green"

        assigned_dates = [a for a in assignments if a['resident'] == r]
        last_collection = assigned_dates[-1]['collection_date'] if assigned_dates else None

        resident_status.append({
            "name": r,
            "status": last_status,
            "color": color,
            "last_collection": last_collection
        })

    return render_template(
        'manager_dashboard.html',
        resident_status=resident_status,
        reports=reports,
        assignments=assignments,
        messages=messages
    )


# --- Assign Waste Collection Dates ---
@app.route('/assign', methods=['POST'])
def assign():
    resident = request.form['resident']
    date = request.form['collection_date']
    assignments.append({
        "resident": resident,
        "collection_date": date
    })
    return redirect(url_for('dashboard'))


# --- Reply to Resident ---
@app.route('/reply', methods=['POST'])
def reply():
    resident = request.form['resident']
    message_text = request.form['message']

    messages.append({
        "sender": "Manager",
        "receiver": resident,
        "text": message_text,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    return redirect(url_for('dashboard'))


# --- Broadcast Message to All Residents ---
@app.route('/broadcast', methods=['POST'])
def broadcast():
    message_text = request.form['message']

    for user in users:
        if users[user]['role'] == "resident":
            messages.append({
                "sender": "Manager",
                "receiver": user,
                "text": message_text,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
    return redirect(url_for('dashboard'))


# --- Resident Inbox Page ---
@app.route('/message/<user>')
def message(user):
    if user not in users or users[user]['role'] != "resident":
        return redirect(url_for('login'))

    user_messages = [m for m in messages if m['receiver'] == user]
    return render_template('message.html', messages=user_messages, user=user)


# --- View Individual Resident Profile (Manager only) ---
@app.route('/resident/<resident>')
def resident_profile(resident):
    if resident not in users or users[resident]['role'] != "resident":
        return redirect(url_for('dashboard'))

    user_reports = [r for r in reports if r['resident'] == resident]
    user_messages = [m for m in messages if m['receiver'] == resident]
    user_assignments = [a for a in assignments if a['resident'] == resident]
    last_collection = user_assignments[-1]['collection_date'] if user_assignments else None

    return render_template(
        'resident_profile.html',
        resident=resident,
        reports=user_reports,
        messages=user_messages,
        assignments=user_assignments,
        last_collection=last_collection
    )


# --- Admin Dashboard ---
@app.route('/admin_dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')

        # Add user
        if action == "add" and username and role:
            users[username] = {"password": password or "1234", "role": role}

        # Delete user (no password required)
        elif action == "delete" and username in users and username != "admin":
            del users[username]

    return render_template(
        'admin_dashboard.html',
        users=users,
        reports=reports,
        messages=messages,
        assignments=assignments
    )


# --- View Any User Profile (Admin only) ---
@app.route('/admin_view/<username>')
def admin_view(username):
    if username not in users:
        return redirect(url_for('admin_dashboard'))

    role = users[username]['role']
    user_reports = [r for r in reports if r.get('resident') == username]
    user_messages = [m for m in messages if m.get('receiver') == username]
    user_assignments = [a for a in assignments if a.get('resident') == username]
    last_collection = user_assignments[-1]['collection_date'] if user_assignments else None

    return render_template(
        'admin_view_user.html',
        username=username,
        role=role,
        reports=user_reports,
        messages=user_messages,
        assignments=user_assignments,
        last_collection=last_collection
    )


# --- Generate System Report ---
@app.route('/generate_report')
def generate_report():
    total_reports = len(reports)
    full_bins = len([r for r in reports if r['status'] == "Full"])
    empty_bins = total_reports - full_bins
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return render_template(
        'generate_report.html',
        total_reports=total_reports,
        full_bins=full_bins,
        empty_bins=empty_bins,
        timestamp=timestamp
    )


# --- Run Application ---
if __name__ == "__main__":
    app.run(debug=True)
