from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html', user=None)

@app.route('/lessons')
def lessons():
    return render_template('lessons.html', user=None)

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    score = None
    user_answers = {}

    correct_answers = {
        'q1': 'b',
        'q2': 'c',
        'q3': 'a',
        'q4': 'a',
        'q5': 'a',
        'q6': 'a',
        'q7': 'c',
        'q8': 'b',
        'q9': 'b',
        'q10': 'b',
        'q11': 'b',
        'q12': 'a',
        'q13': 'b',
        'q14': 'a',
        'q15': 'a'
    }

    if request.method == 'POST':
        score = 0
        for q, correct in correct_answers.items():
            user_choice = request.form.get(q)
            user_answers[q] = user_choice
            if user_choice == correct:
                score += 1

    return render_template('quiz.html',
                           user=None,
                           score=score,
                           user_answers=user_answers,
                           correct_answers=correct_answers)

@app.route('/logout')
def logout():
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
